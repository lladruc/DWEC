//Declarem variables globals.
var idbSupported = false;
var db;
var carreraId;
var carreraCount;

document.addEventListener("DOMContentLoaded", function(){
    if("indexedDB" in window) {
        idbSupported = true;
    }
    if(idbSupported) {
    	indexedDB.deleteDatabase("volta"); //debug mode [borra la BD - desactivat -]
        var openRequest = indexedDB.open("volta",1); //la obra o la crea
        console.log("abierta BD Volta");
 
        openRequest.onupgradeneeded = function(e) {
            console.log("running onupgradeneeded");
            var thisDB = e.target.result;
 //Procedim a crear els contenidors (Taules) //sino existien
            if(!thisDB.objectStoreNames.contains("CURSES")){ 
				thisDB.createObjectStore("CURSES",{autoIncrement: true});
			}
			if(!thisDB.objectStoreNames.contains("EQUIPS")){
				thisDB.createObjectStore ("EQUIPS",{autoIncrement: true});
			}
			if(!thisDB.objectStoreNames.contains("EQUIPSCURSA")){
				thisDB.createObjectStore ("EQUIPSCURSA",{autoIncrement: true});
			}
			if(!thisDB.objectStoreNames.contains("CORREDORS")){
				thisDB.createObjectStore ("CORREDORS",{autoIncrement:true});
			}
			if(!thisDB.objectStoreNames.contains("CORREDORSEQUIP")){
				thisDB.createObjectStore ("CORREDORSEQUIP",{autoIncrement:true});
			}
			if(!thisDB.objectStoreNames.contains("BOSSADALIMENTS")){
				thisDB.createObjectStore ("BOSSADALIMENTS",{autoIncrement: true});
			}
			if(!thisDB.objectStoreNames.contains("HISTORICCORREDORCURSA")){
				thisDB.createObjectStore ("HISTORICCORREDORCURSA",{autoIncrement: true});
			}
 
        }
 
        openRequest.onsuccess = function(e) {
            console.log("Success!");
            db = e.target.result;
        }
 
        openRequest.onerror = function(e) {
            console.log("Error");
            console.dir(e);
        } 
    }
},false);
// funcion base que s'executa al principi i que crea tot o carrega algo generat.

// Crear corredors (crea e inserta un corredor en BD) //se hace automatizado para test
function addCorredor(e) {
  //  var name = document.querySelector("#name").value;
  //  var email = document.querySelector("#email").value;
 //   console.log("About to add "+name+"/"+email);
    var transaction = db.transaction(["CORREDORS"],"readwrite");
    var store = transaction.objectStore("CORREDORS");

    //Define a person
    var person = {
        name:"lladruc",
        idEquipo:1,
        rol:"jefe de filas",
        MetrosMaximosPorTurno:913
        
    }
    //Perform the add
    var request = store.add(person);

    var person = {
        name:"ZentaiKutowa",
        idEquipo:1,
        rol:"Gregario",
        MetrosMaximosPorTurno:870
        
    }
    //Perform the add
    var request = store.add(person);

    var person = {
        name:"microna",
        idEquipo:1,
        rol:"Gregario",
        MetrosMaximosPorTurno:651
        
    }
    //Perform the add
    var request = store.add(person);

    var person = {
        name:"lladruc",
        idEquipo:2,
        rol:"Gregario",
        MetrosMaximosPorTurno:800
        
    }
    //Perform the add
    var request = store.add(person);

    var person = {
        name:"asd2",
        idEquipo:2,
        rol:"Gregario",
        MetrosMaximosPorTurno:512
        
    }
    //Perform the add
    var request = store.add(person);

    var person = {
        name:"Pkins",
        idEquipo:2,
        rol:"jefe de filas",
        MetrosMaximosPorTurno:347
        
    }
    //Perform the add
    var request = store.add(person);
 
    request.onerror = function(e) {
        console.log("Error: ",e.target.error.name);
        //some type of error handler
    }
 
    request.onsuccess = function(e) {
        console.log("Jugadores añadidos");
    }
}


function addEquip(e){
	
	var transaction = db.transaction(["EQUIPS"],"readwrite");
    var store = transaction.objectStore("EQUIPS");
    var equip = {
        name:"Equip1",
        idEquipo:1
    }
    //Perform the add
    var request = store.add(equip);

    var equip = {
        name:"Equip2",
        idEquipo:2
    }
    //Perform the add
    var request = store.add(equip);
    console.log("añadidos los equipos!");
}

function iniciarCarrera(e){
	
	var transaction = db.transaction(["CURSES"],"readwrite");
    var store = transaction.objectStore("CURSES");
    var result;
    var cursa = {
    	id:1,
    	distancia:37000,  //distancia de 37km's (mínim 38 torns)
    	idEquip1:1,
    	idEquip2:2,
    	data:new Date()
    }
    //Perform the add
    var request = store.add(cursa);
    var objectStore = transaction.objectStore("CURSES");
    var ob = objectStore.get(1);
    carreraId = ob;

    ob.onsuccess = function(e) {
		 result = e.target.result;
	//	console.dir(result); // <- Retorna un objeto a la consola
		if(!result) {
            console.log("error al recuperar dades!");
        }   
	}
}

function crearCampoDeBatalla(){

    //obtener datos de todo kiski y arrancar en 0, con el máximo de la carrera puesta

    //mostrar datos al usuario.


    //permitir entrar al historial.

}

function recargarBarra(idBarra,incremento){
    var actual = document.getElementById(idBarra).value;
    var facultativo =(total / 100 * incremento);



}

function setNewPosition(idCorredor){


}


function pasarTiempo(){

//se computan los datos en base a "random",


//se actualizan las tablas


//se muestran los datos actualizados


//se retorna el control al usuario
}